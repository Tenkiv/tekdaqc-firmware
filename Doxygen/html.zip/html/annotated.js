var annotated =
[
    [ "Analog_Input_t", "struct_analog___input__t.html", "struct_analog___input__t" ],
    [ "CalibrationState_t", "struct_calibration_state__t.html", null ],
    [ "Digital_Input_t", "struct_digital___input__t.html", "struct_digital___input__t" ],
    [ "Digital_Output_t", "struct_digital___output__t.html", "struct_digital___output__t" ],
    [ "Tekdaqc_CommandInterpreter_t", "struct_tekdaqc___command_interpreter__t.html", "struct_tekdaqc___command_interpreter__t" ],
    [ "TelnetOpts_t", "struct_telnet_opts__t.html", "struct_telnet_opts__t" ],
    [ "TelnetServer_t", "struct_telnet_server__t.html", "struct_telnet_server__t" ]
];