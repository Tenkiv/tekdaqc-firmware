var _a_d_c___state_machine_8h =
[
    [ "ADC_State_t", "_a_d_c___state_machine_8h.html#gae8acd7c093ba943ff020756662d8e282", [
      [ "ADC_UNINITIALIZED", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282ac1bd0f71a88c6a0448812f5c9bfabc82", null ],
      [ "ADC_INITIALIZED", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282a3dd35159e362e102ff3857defd2ee5ec", null ],
      [ "ADC_CALIBRATING", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282ad44134e74eaafda748b36b62b64b3ffb", null ],
      [ "ADC_GAIN_CALIBRATING", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282a1ce1ead9375dee706ff6e8df4012e845", null ],
      [ "ADC_IDLE", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282aa37cde1dabf7658cc9bb359dc7ad7ce8", null ],
      [ "ADC_CHANNEL_SAMPLING", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282ac39ce4086e8ea9dbbbe721d237b0e58d", null ],
      [ "ADC_RESET", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282a49f30e17bd4e0529efe8855e9dc163bc", null ],
      [ "ADC_EXTERNAL_MUXING", "_a_d_c___state_machine_8h.html#ggae8acd7c093ba943ff020756662d8e282a09bb7081acebf276c0dd4ada41696612", null ]
    ] ],
    [ "ADC_Calibrate", "_a_d_c___state_machine_8h.html#ga7eb6744d5738bf35b1cb86b44cdc99ad", null ],
    [ "ADC_External_Muxing", "_a_d_c___state_machine_8h.html#gafdb90e36c49985480868585799f00b22", null ],
    [ "ADC_GainCalibrate", "_a_d_c___state_machine_8h.html#ga91d632b5c373982d2554840a65e89758", null ],
    [ "ADC_Machine_Create", "_a_d_c___state_machine_8h.html#gaf9ab485b0fb6ddf69c8bfb43597ab06b", null ],
    [ "ADC_Machine_Halt", "_a_d_c___state_machine_8h.html#ga6424732e3475cc653a8e7cd3598555f5", null ],
    [ "ADC_Machine_Idle", "_a_d_c___state_machine_8h.html#gac1ea03f0a36d3488bfb5c728b118942c", null ],
    [ "ADC_Machine_Init", "_a_d_c___state_machine_8h.html#gaabf53da7a14f298b049ed2ad432b0ed6", null ],
    [ "ADC_Machine_Input_Sample", "_a_d_c___state_machine_8h.html#ga979620e2e4743c8f5d1f053a90705841", null ],
    [ "ADC_Machine_Reset", "_a_d_c___state_machine_8h.html#ga82e1537e4763ba13d894276ab9de1cd7", null ],
    [ "ADC_Machine_Service", "_a_d_c___state_machine_8h.html#ga89889fc7c9dba41da2ab451fe5e06d68", null ]
];