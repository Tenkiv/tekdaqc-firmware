var group__tekdaqc__can__interface =
[
    [ "Tekdaqc_CAN_Config", "group__tekdaqc__can__interface.html#gad8e99db65d1f39e1c0b79944d9b3192b", null ]
];