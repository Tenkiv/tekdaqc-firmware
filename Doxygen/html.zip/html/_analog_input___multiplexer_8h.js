var _analog_input___multiplexer_8h =
[
    [ "GetExternalMuxedInputByNumber", "_analog_input___multiplexer_8h.html#ga03f66c16ea15a425062a4b09c0bceba1", null ],
    [ "InputMultiplexerInit", "_analog_input___multiplexer_8h.html#ga7f67e83c34a57a26b88716b132d78c9f", null ],
    [ "isExternalInput", "_analog_input___multiplexer_8h.html#ga82dce77857c1a4197599b5e53d4c4baf", null ],
    [ "isExternalMuxingComplete", "_analog_input___multiplexer_8h.html#ga5b4aed86c91b3b4bbdc4c7e03f6923ef", null ],
    [ "isInternalInput", "_analog_input___multiplexer_8h.html#ga9452ba5ad241ec1be905a8683f3aa893", null ],
    [ "ResetSelectedInput", "_analog_input___multiplexer_8h.html#ga719b0357a9dca76e01dcc6a511cd8b7f", null ],
    [ "SelectAnalogInput", "_analog_input___multiplexer_8h.html#ga3e81c3d2e9e26f8e51f204b6fd5e5a99", null ],
    [ "SelectCalibrationInput", "_analog_input___multiplexer_8h.html#gade4a88985454a90749affb88214a817e", null ],
    [ "SelectColdJunctionInput", "_analog_input___multiplexer_8h.html#gae6210a53610863d94bea3968f43b4e88", null ],
    [ "SelectPhysicalInput", "_analog_input___multiplexer_8h.html#ga42889d7964665696a3f7d8ff10636f44", null ]
];