var group__tekdaqc__communication =
[
    [ "DEBUG_MESSAGE_HEADER", "group__tekdaqc__communication.html#ga9c4bc7a3b0d3be416cbbb1af90028590", null ],
    [ "ERROR_MESSAGE_HEADER", "group__tekdaqc__communication.html#ga6ea1aa40205a4de746a611315727ab7d", null ],
    [ "LOCATOR_PORT", "group__tekdaqc__communication.html#ga5a136fbad6cb2fa002bd9fd5a9288336", null ],
    [ "STATUS_MESSAGE_HEADER", "group__tekdaqc__communication.html#gaed5fb544cd079f2880ed56a2b4ed7015", null ],
    [ "TELNET_PORT", "group__tekdaqc__communication.html#gad036d23530f3aa396f7cc2dba2e8fb2e", null ]
];