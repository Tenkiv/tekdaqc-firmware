var _tekdaqc___calibration_table_8c =
[
    [ "Tekdaqc_Calibration_SetBaseGainValue", "_tekdaqc___calibration_table_8c.html#a82300c4a55d563ea8c11367b11c32215", null ],
    [ "Tekdaqc_CalibrationInit", "_tekdaqc___calibration_table_8c.html#af6ecb791b957781d6401a3019dba657b", null ],
    [ "Tekdaqc_EndCalibrationMode", "_tekdaqc___calibration_table_8c.html#a0c1fa5f649f31632cfa62a1b59b5ae17", null ],
    [ "Tekdaqc_GetGainCalibration", "_tekdaqc___calibration_table_8c.html#a7fdb97e78b7e8036eb9b9dc1053d2f6a", null ],
    [ "Tekdaqc_GetOffsetCalibration", "_tekdaqc___calibration_table_8c.html#ac10ad531169839fabde0444d38594134", null ],
    [ "Tekdaqc_SetBaseGainCalibration", "_tekdaqc___calibration_table_8c.html#a52ecb644642c69543b416a0b480499c7", null ],
    [ "Tekdaqc_SetCalibrationHighTemperature", "_tekdaqc___calibration_table_8c.html#a3864bec21d5077b294b23d177de99db6", null ],
    [ "Tekdaqc_SetCalibrationLowTemperature", "_tekdaqc___calibration_table_8c.html#af7596691e91746a2326357b5c0f7ddd4", null ],
    [ "Tekdaqc_SetCalibrationMode", "_tekdaqc___calibration_table_8c.html#ac005584d9f0811033e24d9f3f3e8519f", null ],
    [ "Tekdaqc_SetCalibrationStepTemperature", "_tekdaqc___calibration_table_8c.html#a3391c5f7bb8b43d1dbd2f047100b35c6", null ],
    [ "Tekdaqc_SetGainCalibration", "_tekdaqc___calibration_table_8c.html#a8f0cb3a405f24587e7ae051211471bc1", null ],
    [ "Tekdaqc_SetOffsetCalibration", "_tekdaqc___calibration_table_8c.html#a87e24b5d31fe4dcf2e5de7408715d70a", null ],
    [ "Tekdaqc_SetSerialNumber", "_tekdaqc___calibration_table_8c.html#a180d881a8974f106b80ea5c1a88e2ae0", null ]
];