var _tek_d_a_q_c___error_8c =
[
    [ "TekDAQC_CheckStatus", "_tek_d_a_q_c___error_8c.html#gab39aa27d7a68182e3c13be826f3d8bae", null ],
    [ "TekDAQC_CommandError_ToString", "_tek_d_a_q_c___error_8c.html#gad5a8ed00d8c5ffb99c9b2030926a6fee", null ],
    [ "TekDAQC_FunctionError_ToString", "_tek_d_a_q_c___error_8c.html#ga680ef45731fb9417ebbd203e77bd6f89", null ]
];