var group__adcon__register =
[
    [ "ADS1256_CO_BIT", "group__adcon__register.html#ga5c128ef483f3f73486edc0926cfdd489", null ],
    [ "ADS1256_CO_SPAN", "group__adcon__register.html#gaca76a3e75786c24c21dcc1f8b95d3c8f", null ],
    [ "ADS1256_PGA_BIT", "group__adcon__register.html#ga331593eda0ade15ce934f8d2188e0f4f", null ],
    [ "ADS1256_PGA_SPAN", "group__adcon__register.html#ga04102c89838c33a2da9fb44d71c9ce16", null ],
    [ "ADS1256_SD_BIT", "group__adcon__register.html#gae9ac3d875a51151679aa3bb5de911286", null ],
    [ "ADS1256_SD_SPAN", "group__adcon__register.html#ga7ccaedf1fc3255f7701cf9512d500a42", null ]
];