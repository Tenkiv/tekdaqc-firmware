var _tekdaqc___r_t_c_8c =
[
    [ "RTC_Config", "_tekdaqc___r_t_c_8c.html#ga1c3df1ec7ceb1e5b7b33833fba06515c", null ]
];