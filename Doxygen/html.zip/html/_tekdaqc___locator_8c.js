var _tekdaqc___locator_8c =
[
    [ "CMD_DISCOVER_TARGET", "_tekdaqc___locator_8c.html#a1c00feb154f59a515e12382b816678da", null ],
    [ "LOCATOR_DATA_LENGTH", "_tekdaqc___locator_8c.html#ab46e92a2b73bcc701b497bed347d410c", null ],
    [ "LocatorAppTitleSet", "_tekdaqc___locator_8c.html#a9404d8297647f20b2c1cf4736380c4ee", null ],
    [ "Tekdaqc_GetLocatorBoardID", "_tekdaqc___locator_8c.html#gae38557024fc843c693d4b6f2cdb5d097", null ],
    [ "Tekdaqc_GetLocatorBoardType", "_tekdaqc___locator_8c.html#ga573f8960093dc2ab0cc4c88b8f8c6ff9", null ],
    [ "Tekdaqc_GetLocatorIp", "_tekdaqc___locator_8c.html#gaf8eaedaeca86f0d5c7af113faebe16a0", null ],
    [ "Tekdaqc_GetLocatorMAC", "_tekdaqc___locator_8c.html#ga03c9656c9876829e12f617d4e4abef04", null ],
    [ "Tekdaqc_GetLocatorVersion", "_tekdaqc___locator_8c.html#ga502ebd4cceffc0fa3a7abefc7f79b42a", null ],
    [ "Tekdaqc_LocatorBoardIDSet", "_tekdaqc___locator_8c.html#ga87bf26021e9bb75cf09e9982a2ce657b", null ],
    [ "Tekdaqc_LocatorBoardTypeSet", "_tekdaqc___locator_8c.html#ga668d2bf16094e0046055c231a3c2174c", null ],
    [ "Tekdaqc_LocatorClientIPSet", "_tekdaqc___locator_8c.html#ga841da02fec8e79caad0f1d3db9a7af73", null ],
    [ "Tekdaqc_LocatorInit", "_tekdaqc___locator_8c.html#ga99090049c7556abdcff2bad0dfdf78af", null ],
    [ "Tekdaqc_LocatorMACAddrSet", "_tekdaqc___locator_8c.html#gaedcc9e5e10826ca40b253bdc274e65cf", null ],
    [ "Tekdaqc_LocatorVersionSet", "_tekdaqc___locator_8c.html#ga852fe5c43e378a8621913254a3e00bd1", null ]
];