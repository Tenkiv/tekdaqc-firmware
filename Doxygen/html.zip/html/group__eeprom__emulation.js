var group__eeprom__emulation =
[
    [ "EE_Init", "group__eeprom__emulation.html#ga83834957567411c76bb7f659cf8a1a38", null ],
    [ "EE_ReadVariable", "group__eeprom__emulation.html#ga0776e2e16f54d3a675e4f2f401703a85", null ],
    [ "EE_WriteVariable", "group__eeprom__emulation.html#ga516e9ced7438b9452c72884aa1df5915", null ]
];