var _digital___input_8h =
[
    [ "MAX_DIGITAL_INPUT_NAME_LENGTH", "_digital___input_8h.html#gaf48b39ba82663f6926d1a02d1e501926", null ],
    [ "AddDigitalInput", "_digital___input_8h.html#ga2f7815dc130460ff54b2f21d0864bf8f", null ],
    [ "CreateDigitalInput", "_digital___input_8h.html#ga5b4bb29221f6aafe926340eafcf7f722", null ],
    [ "DigitalInputsInit", "_digital___input_8h.html#gacf4e27adc3b6643e12e01e4d1000db63", null ],
    [ "GetDigitalInputByNumber", "_digital___input_8h.html#gadfa62573aaa64c6bdcbb94c164099154", null ],
    [ "ListDigitalInputs", "_digital___input_8h.html#gaf5dbc88e9aa5cee34b35d908a2e61276", null ],
    [ "RemoveDigitalInput", "_digital___input_8h.html#ga3b0d15fea40d84eaf677d216e1530d89", null ],
    [ "SampleAllDigitalInputs", "_digital___input_8h.html#gaaa11463a9a8f8ae76ebd26ca8331e734", null ],
    [ "SampleDigitalInput", "_digital___input_8h.html#ga8c060a2a592e2644ffe8efdb198637f2", null ],
    [ "SetDigitalInputWriteFunction", "_digital___input_8h.html#ga77861794e1f3432e96903fee5fe1bc2b", null ],
    [ "WriteAllDigitalInputs", "_digital___input_8h.html#gaffb0acdfc01e77cc785bda2fbbe1c367", null ],
    [ "WriteDigitalInput", "_digital___input_8h.html#ga007c56810797c98a6c03ac2836ad9328", null ]
];