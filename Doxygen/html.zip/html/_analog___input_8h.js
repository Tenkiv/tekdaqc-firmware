var _analog___input_8h =
[
    [ "ANALOG_INPUT_BUFFER_SIZE", "_analog___input_8h.html#ga3f128795c69a685d5e905c4117008271", null ],
    [ "MAX_ANALOG_INPUT_NAME_LENGTH", "_analog___input_8h.html#ga7b523129daacaeca69045b3adb1aaf54", null ],
    [ "AnalogInputStatus_t", "_analog___input_8h.html#ga99258f91accf55ecea49707692a3889b", [
      [ "BELOW_RANGE", "_analog___input_8h.html#gga99258f91accf55ecea49707692a3889baab4ee4ac298eaa158dc5d14eb9ca8b60", null ],
      [ "IN_RANGE", "_analog___input_8h.html#gga99258f91accf55ecea49707692a3889ba19a150b47d1db72e2947bef12bd1ca7f", null ],
      [ "ABOVE_RANGE", "_analog___input_8h.html#gga99258f91accf55ecea49707692a3889baa2ccf1ed52430dd6b0070370d5125d7e", null ]
    ] ],
    [ "AddAnalogInput", "_analog___input_8h.html#gab88a5ebe3b0749d880eec3c892649454", null ],
    [ "AnalogInputsInit", "_analog___input_8h.html#gaf65fcf2267ddebcf80049303dc9507ce", null ],
    [ "CreateAnalogInput", "_analog___input_8h.html#gacdd326a56de1d837605d610cc638a959", null ],
    [ "ExtAnalogInputToString", "_analog___input_8h.html#ga87d73c733aa66effbdafe2a15b7c4a54", null ],
    [ "GetAnalogInputByNumber", "_analog___input_8h.html#ga697505715d2411ad856bca3d1e726913", null ],
    [ "IntAnalogInputToString", "_analog___input_8h.html#gae568c96624ef9e126175706f85eec3b4", null ],
    [ "ListAnalogInputs", "_analog___input_8h.html#ga30736f8a2ceb6a1993055302893efefe", null ],
    [ "RemoveAnalogInput", "_analog___input_8h.html#ga221c8c5a1bbe659d613fa81a6a834dd9", null ],
    [ "SetAnalogInputWriteFunction", "_analog___input_8h.html#ga8230666b0182b4ce633c20860b5146ff", null ],
    [ "WriteAnalogInput", "_analog___input_8h.html#ga3d7d6daf5f4b4a4c455dd9b9aec6053b", null ]
];