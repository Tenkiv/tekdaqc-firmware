var group__rtc__driver =
[
    [ "RTC_Config", "group__rtc__driver.html#ga1c3df1ec7ceb1e5b7b33833fba06515c", null ]
];