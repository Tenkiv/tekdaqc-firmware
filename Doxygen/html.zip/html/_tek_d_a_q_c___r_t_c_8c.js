var _tek_d_a_q_c___r_t_c_8c =
[
    [ "RTC_Config", "_tek_d_a_q_c___r_t_c_8c.html#ga1c3df1ec7ceb1e5b7b33833fba06515c", null ]
];