var _tekdaqc___calibration_8h =
[
    [ "isTekdaqc_CalibrationValid", "_tekdaqc___calibration_8h.html#gae09f531b1b83f3e80e981f14bfc27261", null ],
    [ "PerformSystemCalibration", "_tekdaqc___calibration_8h.html#ga8aa6dd97a6551e9ca12b12439eec2332", null ],
    [ "PerformSystemGainCalibration", "_tekdaqc___calibration_8h.html#ga65885f14ff00d87bd3ca21265e7d26f6", null ]
];