var group__io__register =
[
    [ "ADS1256_GPIO_BIT_SPAN", "group__io__register.html#gaae5e18a5051bc2b7c8f7ff4237edae2a", null ],
    [ "ADS1256_GPIO_DIR_OFFSET", "group__io__register.html#ga79e29004c3a9381caf716a834ad58426", null ]
];