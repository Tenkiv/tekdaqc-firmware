var modules =
[
    [ "Tekdaqc Firmware", "group__tekdaqc__firmware.html", "group__tekdaqc__firmware" ],
    [ "Tekdaqc Firmware Libraries", "group__tekdaqc__firmware__libraries.html", "group__tekdaqc__firmware__libraries" ]
];