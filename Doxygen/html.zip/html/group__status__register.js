var group__status__register =
[
    [ "ADS1256_ACAL_BIT", "group__status__register.html#ga94588026849071dfdf4bacbdbf24976a", null ],
    [ "ADS1256_ACAL_SPAN", "group__status__register.html#gacccdeffab4e1942cec3794851ef228c7", null ],
    [ "ADS1256_BUFFEN_BIT", "group__status__register.html#ga2cbdb7cbaac91a12c2818e87b97a4906", null ],
    [ "ADS1256_BUFFEN_SPAN", "group__status__register.html#gae477a7ad4b56f4a0579a674f5ef44d26", null ],
    [ "ADS1256_DRDY_BIT", "group__status__register.html#ga8836defa503977dda06238596f6bb8e3", null ],
    [ "ADS1256_DRDY_SPAN", "group__status__register.html#ga39195cf60d4a91b0b61a5461ed1a5a67", null ],
    [ "ADS1256_ID_BIT", "group__status__register.html#ga14da33a69f54e320a00c3e33e9dcf44a", null ],
    [ "ADS1256_ID_SPAN", "group__status__register.html#ga4b89c536e185cfdbd9fa248a3e3772b7", null ],
    [ "ADS1256_ORDER_BIT", "group__status__register.html#ga295221d00dc4ae777c591ffdbc7f8922", null ],
    [ "ADS1256_ORDER_SPAN", "group__status__register.html#gaa07ca51df9b9ce477186cf92d331a59c", null ]
];