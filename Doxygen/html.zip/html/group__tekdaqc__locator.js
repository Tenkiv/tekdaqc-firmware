var group__tekdaqc__locator =
[
    [ "Tekdaqc_GetLocatorBoardID", "group__tekdaqc__locator.html#gae38557024fc843c693d4b6f2cdb5d097", null ],
    [ "Tekdaqc_GetLocatorBoardType", "group__tekdaqc__locator.html#ga573f8960093dc2ab0cc4c88b8f8c6ff9", null ],
    [ "Tekdaqc_GetLocatorIp", "group__tekdaqc__locator.html#gaf8eaedaeca86f0d5c7af113faebe16a0", null ],
    [ "Tekdaqc_GetLocatorMAC", "group__tekdaqc__locator.html#ga03c9656c9876829e12f617d4e4abef04", null ],
    [ "Tekdaqc_GetLocatorVersion", "group__tekdaqc__locator.html#ga502ebd4cceffc0fa3a7abefc7f79b42a", null ],
    [ "Tekdaqc_LocatorAppTitleSet", "group__tekdaqc__locator.html#gadcd8af9370fe58374d5355c66651b620", null ],
    [ "Tekdaqc_LocatorBoardIDSet", "group__tekdaqc__locator.html#ga87bf26021e9bb75cf09e9982a2ce657b", null ],
    [ "Tekdaqc_LocatorBoardTypeSet", "group__tekdaqc__locator.html#ga668d2bf16094e0046055c231a3c2174c", null ],
    [ "Tekdaqc_LocatorClientIPSet", "group__tekdaqc__locator.html#ga841da02fec8e79caad0f1d3db9a7af73", null ],
    [ "Tekdaqc_LocatorInit", "group__tekdaqc__locator.html#ga99090049c7556abdcff2bad0dfdf78af", null ],
    [ "Tekdaqc_LocatorMACAddrSet", "group__tekdaqc__locator.html#gaedcc9e5e10826ca40b253bdc274e65cf", null ],
    [ "Tekdaqc_LocatorVersionSet", "group__tekdaqc__locator.html#ga852fe5c43e378a8621913254a3e00bd1", null ]
];