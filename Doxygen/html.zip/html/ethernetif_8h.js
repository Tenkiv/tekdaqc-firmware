var ethernetif_8h =
[
    [ "ethernetif_init", "ethernetif_8h.html#ga7ce979d0ec31575ecf17998b7bd9abb2", null ],
    [ "ethernetif_input", "ethernetif_8h.html#ga10211a021d1a1fe2398d246eb76ac354", null ]
];