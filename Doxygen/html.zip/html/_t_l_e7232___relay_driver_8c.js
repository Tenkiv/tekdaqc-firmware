var _t_l_e7232___relay_driver_8c =
[
    [ "SetOutputFaultStatusFunction", "_t_l_e7232___relay_driver_8c.html#ga1db076dc4fbbff6d149a2a80f3070e6a", null ],
    [ "TLE7232_GetDiagnosis", "_t_l_e7232___relay_driver_8c.html#ga70b056c53eb119997811f7d942007109", null ],
    [ "TLE7232_Init", "_t_l_e7232___relay_driver_8c.html#ga97ef893379ebeb042e738b4cecfa8bff", null ],
    [ "TLE7232_ReadAllDiagnosis", "_t_l_e7232___relay_driver_8c.html#gadefac9d800f68f872c6c8c4d5b3379cd", null ],
    [ "TLE7232_ReadArbitraryRegisterAll", "_t_l_e7232___relay_driver_8c.html#ga6e1abd4edfc5d3be4de3f98716b21786", null ],
    [ "TLE7232_ReadDiagnosis", "_t_l_e7232___relay_driver_8c.html#ga82fd3520b4ff7c04460d6e37490a29eb", null ],
    [ "TLE7232_ReadRegister", "_t_l_e7232___relay_driver_8c.html#ga5d2ff3c331e9b1bd5d1d4522ffc92b5d", null ],
    [ "TLE7232_ReadRegisterAll", "_t_l_e7232___relay_driver_8c.html#ga69d5853d67c276595fc03169822f65f9", null ],
    [ "TLE7232_Reset", "_t_l_e7232___relay_driver_8c.html#ga307b487187274ea82fd8f1674a0e2d3c", null ],
    [ "TLE7232_ResetAllRegisters", "_t_l_e7232___relay_driver_8c.html#gac27a30e4da66392e2a53b1414aa3c9cb", null ],
    [ "TLE7232_ResetRegisters", "_t_l_e7232___relay_driver_8c.html#ga5b83ed93b7c747534e40c3b6a0cd994e", null ],
    [ "TLE7232_WriteArbitraryRegisterAll", "_t_l_e7232___relay_driver_8c.html#gaf3e85d7d9a54143703684223ac382b9e", null ],
    [ "TLE7232_WriteRegister", "_t_l_e7232___relay_driver_8c.html#gabf56c66110adfb8658cff9c2f6fc5cd6", null ],
    [ "TLE7232_WriteRegisterAll", "_t_l_e7232___relay_driver_8c.html#ga082ee2578c277c689e4ce6c0647cdcf5", null ]
];