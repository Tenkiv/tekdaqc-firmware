var _tek_d_a_q_c__config_8c =
[
    [ "ClearToStringBuffer", "_tek_d_a_q_c__config_8c.html#ga7fee54fd2d4e5ad001547a64d519bdb1", null ],
    [ "COMInit", "_tek_d_a_q_c__config_8c.html#gaec08ef6f9e4d5e29da8f7af0490930b7", null ],
    [ "Communication_Init", "_tek_d_a_q_c__config_8c.html#ga77b9940dbe07de4765c23c27baf1de40", null ],
    [ "DigitalLevelToString", "_tek_d_a_q_c__config_8c.html#ga5aeffa7a603f954a637f967f37c29ec6", null ],
    [ "FlashDiskInit", "_tek_d_a_q_c__config_8c.html#ga38dfe3d6b1f6f3da8b74612f51b0f479", null ],
    [ "GetSerialNumber", "_tek_d_a_q_c__config_8c.html#gabd78ed6a110b5878ee2388cb706ada9a", null ],
    [ "Watchdog_Init", "_tek_d_a_q_c__config_8c.html#ga495a07bd1939981855363ee899e619ed", null ]
];