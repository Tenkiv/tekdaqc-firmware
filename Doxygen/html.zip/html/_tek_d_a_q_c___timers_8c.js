var _tek_d_a_q_c___timers_8c =
[
    [ "Delay_ms", "_tek_d_a_q_c___timers_8c.html#gaf7d18dc0155f873c4ed1d149e6060d19", null ],
    [ "Delay_Periods", "_tek_d_a_q_c___timers_8c.html#ga1431937e39123e5e4fddcfbdec5aa70e", null ],
    [ "Delay_Periods_10MS", "_tek_d_a_q_c___timers_8c.html#gaa826dcc6214549a3ae300594de880024", null ],
    [ "Delay_us", "_tek_d_a_q_c___timers_8c.html#ga5ec7c1ff1d0645d24d030f36382e9417", null ],
    [ "GetLocalTime", "_tek_d_a_q_c___timers_8c.html#ga11a66b1728633b77403a588f66a1be95", null ],
    [ "Time_Update", "_tek_d_a_q_c___timers_8c.html#ga194e6c4226839758664f0e68816c0713", null ],
    [ "Timer_Config", "_tek_d_a_q_c___timers_8c.html#ga3c15420197589e14aa4da4b880a8005f", null ]
];