var searchData=
[
  ['logic_5fhigh',['LOGIC_HIGH',['../group__board__channel__constants.html#ggaee574a0d48c41a3e5426ffbf8ac4c5c4ad49fd7cec8a5997c9347759048470fc9',1,'Tekdaqc_BSP.h']]],
  ['logic_5flow',['LOGIC_LOW',['../group__board__channel__constants.html#ggaee574a0d48c41a3e5426ffbf8ac4c5c4ab4d04526d504d52286c0125def0faef4',1,'Tekdaqc_BSP.h']]]
];
