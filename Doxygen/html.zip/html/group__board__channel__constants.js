var group__board__channel__constants =
[
    [ "ChannelAdded_t", "group__board__channel__constants.html#gab0f30599ceb99e5ba3b2908d8e9bd131", [
      [ "CHANNEL_ADDED", "group__board__channel__constants.html#ggab0f30599ceb99e5ba3b2908d8e9bd131aaee2b8395093e69408a16f6981d07fa9", null ],
      [ "CHANNEL_NOTADDED", "group__board__channel__constants.html#ggab0f30599ceb99e5ba3b2908d8e9bd131a4ecfadabb635f0b5dd33b66498b2d04f", null ]
    ] ],
    [ "DigitalLevel_t", "group__board__channel__constants.html#gaee574a0d48c41a3e5426ffbf8ac4c5c4", [
      [ "LOGIC_HIGH", "group__board__channel__constants.html#ggaee574a0d48c41a3e5426ffbf8ac4c5c4ad49fd7cec8a5997c9347759048470fc9", null ],
      [ "LOGIC_LOW", "group__board__channel__constants.html#ggaee574a0d48c41a3e5426ffbf8ac4c5c4ab4d04526d504d52286c0125def0faef4", null ]
    ] ]
];