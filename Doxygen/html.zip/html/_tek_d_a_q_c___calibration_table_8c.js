var _tek_d_a_q_c___calibration_table_8c =
[
    [ "TekDAQC_Calibration_SetBaseGainValue", "_tek_d_a_q_c___calibration_table_8c.html#ad82f81dbfbf24a20d6d3cd0854f80bd9", null ],
    [ "TekDAQC_CalibrationInit", "_tek_d_a_q_c___calibration_table_8c.html#a7adb48554d765127b2e082f83e933b9d", null ],
    [ "TekDAQC_EndCalibrationMode", "_tek_d_a_q_c___calibration_table_8c.html#a1da0f59c5fdb39d8893541b828003493", null ],
    [ "TekDAQC_GetGainCalibration", "_tek_d_a_q_c___calibration_table_8c.html#ac8b0adbe7504bd2b7350a842345c4357", null ],
    [ "TekDAQC_GetOffsetCalibration", "_tek_d_a_q_c___calibration_table_8c.html#a227419dde42e8109515594cf91e4f4cb", null ],
    [ "TekDAQC_SetBaseGainCalibration", "_tek_d_a_q_c___calibration_table_8c.html#a4d36462f3a897fe1d2d30feca721053c", null ],
    [ "TekDAQC_SetCalibrationHighTemperature", "_tek_d_a_q_c___calibration_table_8c.html#a3d5db9985fece5b11736ce8cdb1a786a", null ],
    [ "TekDAQC_SetCalibrationLowTemperature", "_tek_d_a_q_c___calibration_table_8c.html#ad319f18d04a69c97b403a1d7e0a27696", null ],
    [ "TekDAQC_SetCalibrationMode", "_tek_d_a_q_c___calibration_table_8c.html#a70c28c72bea0847b4f573196a947c39b", null ],
    [ "TekDAQC_SetCalibrationStepTemperature", "_tek_d_a_q_c___calibration_table_8c.html#a734a97e9c887d2929f90f8f7ea99d9ab", null ],
    [ "TekDAQC_SetGainCalibration", "_tek_d_a_q_c___calibration_table_8c.html#a1e4d430f2646f91dd066418b77ec1a81", null ],
    [ "TekDAQC_SetOffsetCalibration", "_tek_d_a_q_c___calibration_table_8c.html#a0734f2de87e15e76947259596af412a5", null ],
    [ "TekDAQC_SetSerialNumber", "_tek_d_a_q_c___calibration_table_8c.html#a0fc98de46de5ba2db8b894c3377f4e82", null ]
];