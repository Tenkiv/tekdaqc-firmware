var _board_temperature_8h =
[
    [ "getBoardTemperature", "_board_temperature_8h.html#ga84f2a5a76c0781a00449e4e71a8db0bc", null ],
    [ "getMaximumBoardTemperature", "_board_temperature_8h.html#gabd8a85a7dd96f5aa9826e7a0999f738c", null ],
    [ "getMinimumBoardTemperature", "_board_temperature_8h.html#ga2e1ba0973955b1358d76f0da459a36e2", null ],
    [ "updateBoardTemperature", "_board_temperature_8h.html#ga836b49ee7ee49ad9e13dc50a80fa7a0a", null ]
];