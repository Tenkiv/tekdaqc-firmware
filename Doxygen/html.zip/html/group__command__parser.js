var group__command__parser =
[
    [ "MAX_COMMANDLINE_LENGTH", "group__command__parser.html#gaab74dfff7eb006955f2aabec581f8d9f", null ],
    [ "MAX_COMMANDPART_LENGTH", "group__command__parser.html#ga6147771b5547853f33eb838895e3d5a2", null ]
];