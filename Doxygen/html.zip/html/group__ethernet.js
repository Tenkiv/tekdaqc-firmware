var group__ethernet =
[
    [ "ethernetif_init", "group__ethernet.html#ga7ce979d0ec31575ecf17998b7bd9abb2", null ],
    [ "ethernetif_input", "group__ethernet.html#ga10211a021d1a1fe2398d246eb76ac354", null ]
];