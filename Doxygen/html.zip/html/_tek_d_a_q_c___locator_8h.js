var _tek_d_a_q_c___locator_8h =
[
    [ "TekDAQC_GetLocatorBoardID", "_tek_d_a_q_c___locator_8h.html#gadbb41980f31e110577fe3acbddd9ffbd", null ],
    [ "TekDAQC_GetLocatorBoardType", "_tek_d_a_q_c___locator_8h.html#ga6b8f76481961d8ada2321b8986fa3ae0", null ],
    [ "TekDAQC_GetLocatorIp", "_tek_d_a_q_c___locator_8h.html#gaafdbc2afba38909a0dd9183e8a749d8a", null ],
    [ "TekDAQC_GetLocatorMAC", "_tek_d_a_q_c___locator_8h.html#gac2bef6dcb2ec0a768d5dd6523e4b5339", null ],
    [ "TekDAQC_GetLocatorVersion", "_tek_d_a_q_c___locator_8h.html#gaf826dd1488881cbe0360a51168fde64b", null ],
    [ "TekDAQC_LocatorAppTitleSet", "_tek_d_a_q_c___locator_8h.html#ga824dd9136afbd8a274fa32b23e48bc15", null ],
    [ "TekDAQC_LocatorBoardIDSet", "_tek_d_a_q_c___locator_8h.html#ga62434a6c5a62cde49547d0da6a11dc2d", null ],
    [ "TekDAQC_LocatorBoardTypeSet", "_tek_d_a_q_c___locator_8h.html#ga9a0234c50ab9998b9fa891415aa74916", null ],
    [ "TekDAQC_LocatorClientIPSet", "_tek_d_a_q_c___locator_8h.html#gaccaaedc4f7bf5caaa8617e1322d9f808", null ],
    [ "TekDAQC_LocatorInit", "_tek_d_a_q_c___locator_8h.html#ga7575264242a9cfd52bb8f652f6e81512", null ],
    [ "TekDAQC_LocatorMACAddrSet", "_tek_d_a_q_c___locator_8h.html#ga8231071de5c32c4bc9a504787974800a", null ],
    [ "TekDAQC_LocatorVersionSet", "_tek_d_a_q_c___locator_8h.html#ga8110d62d8549fa33651305631a35f09e", null ]
];