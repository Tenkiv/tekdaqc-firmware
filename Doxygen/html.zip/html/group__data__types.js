var group__data__types =
[
    [ "FALSE", "group__data__types.html#gaa93f0eb578d23995850d61f7d61c55c1", null ],
    [ "false", "group__data__types.html#ga65e9886d74aaee76545e83dd09011727", null ],
    [ "TRUE", "group__data__types.html#gaa8cecfc5c5c054d2875c03e77b7be15d", null ],
    [ "true", "group__data__types.html#ga41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "BOOL", "group__data__types.html#gad2f8ed01c1733d4eab0932d970abaa4c", null ],
    [ "bool", "group__data__types.html#ga0ecf26b576b9a54eca656b9be7ba6a06", null ]
];