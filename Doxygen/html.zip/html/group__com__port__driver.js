var group__com__port__driver =
[
    [ "COM1_USART", "group__com__port__driver.html#ga5e1bf137a61b8d8536c6ddf16db0b2e3", null ],
    [ "COM2_USART", "group__com__port__driver.html#ga5907fc16d2de43c1f80f0de8b68a577a", null ]
];