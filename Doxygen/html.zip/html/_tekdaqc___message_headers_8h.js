var _tekdaqc___message_headers_8h =
[
    [ "DEBUG_MESSAGE_HEADER", "_tekdaqc___message_headers_8h.html#ga9c4bc7a3b0d3be416cbbb1af90028590", null ],
    [ "ERROR_MESSAGE_HEADER", "_tekdaqc___message_headers_8h.html#ga6ea1aa40205a4de746a611315727ab7d", null ],
    [ "STATUS_MESSAGE_HEADER", "_tekdaqc___message_headers_8h.html#gaed5fb544cd079f2880ed56a2b4ed7015", null ]
];