var _tekdaqc___error_8c =
[
    [ "Tekdaqc_CheckStatus", "_tekdaqc___error_8c.html#ga5da23e6c262bd5e28f3b73a588470493", null ],
    [ "Tekdaqc_CommandError_ToString", "_tekdaqc___error_8c.html#ga9e4249e557d2ff186f09a6f941bfcaa2", null ],
    [ "Tekdaqc_FunctionError_ToString", "_tekdaqc___error_8c.html#ga82d499e0314eb5c3bdab515f82be322c", null ]
];