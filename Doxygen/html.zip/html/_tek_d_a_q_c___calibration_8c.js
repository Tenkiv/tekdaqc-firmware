var _tek_d_a_q_c___calibration_8c =
[
    [ "isTekDAQC_CalibrationValid", "_tek_d_a_q_c___calibration_8c.html#ga2383637cbb6abb9067966612994a7a77", null ],
    [ "PerformSystemCalibration", "_tek_d_a_q_c___calibration_8c.html#ga1ef95920df00a600e206c7fd66299d58", null ],
    [ "PerformSystemGainCalibration", "_tek_d_a_q_c___calibration_8c.html#gaf50220493125e16ead3770f914463286", null ]
];