var _tekdaqc___locator_8h =
[
    [ "Tekdaqc_GetLocatorBoardID", "_tekdaqc___locator_8h.html#gae38557024fc843c693d4b6f2cdb5d097", null ],
    [ "Tekdaqc_GetLocatorBoardType", "_tekdaqc___locator_8h.html#ga573f8960093dc2ab0cc4c88b8f8c6ff9", null ],
    [ "Tekdaqc_GetLocatorIp", "_tekdaqc___locator_8h.html#gaf8eaedaeca86f0d5c7af113faebe16a0", null ],
    [ "Tekdaqc_GetLocatorMAC", "_tekdaqc___locator_8h.html#ga03c9656c9876829e12f617d4e4abef04", null ],
    [ "Tekdaqc_GetLocatorVersion", "_tekdaqc___locator_8h.html#ga502ebd4cceffc0fa3a7abefc7f79b42a", null ],
    [ "Tekdaqc_LocatorAppTitleSet", "_tekdaqc___locator_8h.html#gadcd8af9370fe58374d5355c66651b620", null ],
    [ "Tekdaqc_LocatorBoardIDSet", "_tekdaqc___locator_8h.html#ga87bf26021e9bb75cf09e9982a2ce657b", null ],
    [ "Tekdaqc_LocatorBoardTypeSet", "_tekdaqc___locator_8h.html#ga668d2bf16094e0046055c231a3c2174c", null ],
    [ "Tekdaqc_LocatorClientIPSet", "_tekdaqc___locator_8h.html#ga841da02fec8e79caad0f1d3db9a7af73", null ],
    [ "Tekdaqc_LocatorInit", "_tekdaqc___locator_8h.html#ga99090049c7556abdcff2bad0dfdf78af", null ],
    [ "Tekdaqc_LocatorMACAddrSet", "_tekdaqc___locator_8h.html#gaedcc9e5e10826ca40b253bdc274e65cf", null ],
    [ "Tekdaqc_LocatorVersionSet", "_tekdaqc___locator_8h.html#ga852fe5c43e378a8621913254a3e00bd1", null ]
];